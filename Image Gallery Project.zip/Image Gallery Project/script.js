document.addEventListener("DOMContentLoaded", () => {
  const searchInput = document.getElementById("searchInput");
  const filterButtons = document.querySelectorAll(".filter-btn");
  const images = document.querySelectorAll(".gallery img");

  const lightbox = document.getElementById("lightbox");
  const lightboxImg = document.querySelector(".lightbox-img");
  const closeBtn = document.querySelector(".close");
  const prevBtn = document.querySelector(".prev");
  const nextBtn = document.querySelector(".next");

  let currentIndex = 0;
  let visibleImages = [];

  // Filter buttons
  filterButtons.forEach(button => {
    button.addEventListener("click", () => {
      const category = button.dataset.category;
      images.forEach(img => {
        const isVisible = category === "all" || img.dataset.category === category;
        img.style.display = isVisible ? "block" : "none";
      });
      updateVisibleImages();
    });
  });

  // Search filter
  searchInput.addEventListener("input", () => {
    const term = searchInput.value.toLowerCase();
    images.forEach(img => {
      const isVisible = img.alt.toLowerCase().includes(term);
      img.style.display = isVisible ? "block" : "none";
    });
    updateVisibleImages();
  });

  // Update visible images list
  function updateVisibleImages() {
    visibleImages = Array.from(images).filter(img => img.style.display !== "none");
  }

  // Lightbox
  images.forEach((img, index) => {
    img.addEventListener("click", () => {
      updateVisibleImages();
      currentIndex = visibleImages.indexOf(img);
      showLightbox();
    });
  });

  function showLightbox() {
    lightbox.style.display = "flex";
    lightboxImg.src = visibleImages[currentIndex].src;
  }

  function hideLightbox() {
    lightbox.style.display = "none";
  }

  function showNext() {
    currentIndex = (currentIndex + 1) % visibleImages.length;
    showLightbox();
  }

  function showPrev() {
    currentIndex = (currentIndex - 1 + visibleImages.length) % visibleImages.length;
    showLightbox();
  }

  closeBtn.addEventListener("click", hideLightbox);
  nextBtn.addEventListener("click", showNext);
  prevBtn.addEventListener("click", showPrev);

  lightbox.addEventListener("click", (e) => {
    if (e.target === lightbox) hideLightbox();
  });

  updateVisibleImages(); // initialize
});
